﻿namespace Интерпретатор_машины_Тьюринга
{
    public class PerformanceRecord
    {
        public string Course { get; set; }
        public string Group { get; set; }
        public string Name { get; set; }
        public string Task { get; set; }
        public string Type { get; set; }
        public int? Grade { get; set; }
        public string Status { get; set; }
        public string GradingPolicy { get; set; }
    }
}
